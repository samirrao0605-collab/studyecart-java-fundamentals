public class Main {

    public static void main(String[] args) {

        Car car1 = new Car(101, "Tesla", "Model 3", 45000.50);

        car1.startEngine();
        car1.displayDetails();

        car1.setPrice(50000.00);

        System.out.println("Updated Price: " + car1.getPrice());

        car1.stopEngine();
    }
}