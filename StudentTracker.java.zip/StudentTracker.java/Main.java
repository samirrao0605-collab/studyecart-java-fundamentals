public class Main {
    public static void main(String[] args) {

        Student student1 = new Student(101, "Anmol", 89.5);
        Student student2 = new Student(102, "Charan", 92.0);
        student1.displayStudentDetails();
        student2.displayStudentDetails();
    }
}