public class Main {

    public static void main(String[] args) {

        Electronics laptop =
                new Electronics(101,"Laptop",50000,2);

        Clothing tshirt =
                new Clothing(201,"T-Shirt",999,"L","Cotton");

        laptop.displayElectronics();
        System.out.println();
        tshirt.displayClothing();
    }
}