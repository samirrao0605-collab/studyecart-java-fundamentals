public class Car{
    private int carID;
    private String brandName;
    private String modelName;
    private double price;
    private boolean engineStarted;
    //Constructor
    Car(int carID,String brandName,String modelName,double price){
        this.carID=carID;
        this.brandName=brandName;
        this.modelName=modelName;
        this.price=price;
        this.engineStarted=false;
    }
    // Getters
    public int getCarId() {
        return carID;
    }

    public String getBrand() {
        return brandName;
    }

    public String getModel() {
        return modelName;
    }

    public double getPrice() {
        return price;
    }

    public boolean isEngineStarted() {
        return engineStarted;
    }

    // Setters
    public void setCarId(int carId) {
        this.carID = carId;
    }

    public void setBrand(String brand) {
        this.brandName = brand;
    }

    public void setModel(String model) {
        this.modelName = model;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Methods
    public void startEngine() {
        engineStarted = true;
        System.out.println("Engine Started");
    }

    public void stopEngine() {
        engineStarted = false;
        System.out.println("Engine Stopped");
    }


    public void displayDetails() {
        System.out.println("Product ID: " + carID);
        System.out.println("Product Name: " + brandName);
        System.out.println("Model Name: " + modelName);
        System.out.println("Price: " + price);
        System.out.println("Engine Started: " + engineStarted);
        System.out.println("----------------------");
    }
    }