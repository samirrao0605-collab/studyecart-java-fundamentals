public class Student{
    private int studentId;
    private String name;
    private double grade;

    Student(int SId,String n,double g){
        this.studentId=SId;
        this.name=n;
        this.grade=g;
    }
    public int getStudentId(){
        return studentId;
    }
    public void setStudentId(int i){
        this.studentId=i;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public double getGrade(){
        return grade;
    }
    public void setGrade(double grade){
        this.grade=grade;
    }
    public void displayStudentDetails() {
        System.out.println("Student ID: " + studentId);
        System.out.println("Name: " + name);
        System.out.println("Grade: " + grade);
        System.out.println("----------------------");
    }
}