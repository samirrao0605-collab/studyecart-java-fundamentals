public class Clothing extends Product {

    private String size;
    private String material;

    public Clothing(int productId,String productName,double basePrice,String size,String material) {
        super(productId, productName, basePrice);

        this.size = size;
        this.material = material;
    }

    public void displayClothing() {
        displayDetails();

        System.out.println("Size: " + size);
        System.out.println("Material: " + material);
    }
}