public class Electronics extends Product {

    private int warrantyYears;

    public Electronics(int productId,String productName,double basePrice,int warrantyYears) {
        super(productId, productName, basePrice);
        this.warrantyYears = warrantyYears;
    }
    public void displayElectronics() {
        displayDetails();
        System.out.println("Warranty: " + warrantyYears + " years");
    }
}