public class Product {

    protected int productId;
    protected String productName;
    protected double basePrice;

    public Product(int productId, String productName, double basePrice) {
        this.productId = productId;
        this.productName = productName;
        this.basePrice = basePrice;
    }

    public void displayDetails() {
        System.out.println("ID: " + productId);
        System.out.println("Name: " + productName);
        System.out.println("Price: " + basePrice);
    }
}